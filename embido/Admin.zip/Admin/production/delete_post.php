<?php 
require_once 'check_session.php';
require_once 'code/config.php';
require_once 'header.php' ; 
$post_id = base64_decode($_GET['code']);
$sql_posts = "delete from `tbl_posts` where `post_id` = '$post_id' ";
$query_posts = mysqli_query($con,$sql_posts);
$affected_row = mysqli_affected_rows($con);
if($affected_row > 0)
{
	echo '<script>alert("Post deleted successfully");</script>';
	$url = base_url()."post.php";
	echo '<script>window.location.href = "'.$url.'";</script>';
}
else
{
	echo '<script>alert("Post can not be deleted");</script>';
	$url = base_url()."post.php";
	echo '<script>window.location.href = "'.$url.'";</script>';
}
?>