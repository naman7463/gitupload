<?php 
require_once 'check_session.php';
require_once 'code/config.php';
require_once 'header.php' ; 

$user_id = $_POST['user_id'];
$full_name = $_POST['full_name'];
$email_id = $_POST['email_id'];
$user_image_name = time().$_FILES["user_image"]["name"];
$user_image_path = $_FILES["user_image"]["tmp_name"];
if(!empty($user_image_name))
{
	move_uploaded_file($user_image_path,$_SERVER['DOCUMENT_ROOT'].'/gofisik/upload/'.$user_image_name);
	$sql_users = "update `tbl_users` set `full_name` = '$full_name' , `email_id` = '$email_id' , `media` = '$user_image_name' where `user_id` = '$user_id' ";
}
else
{
	$sql_users = "update `tbl_users` set `full_name` = '$full_name' , `email_id` = '$email_id'  where `user_id` = '$user_id' ";
}

// update record


$query_posts = mysqli_query($con,$sql_users);
$affected_row = mysqli_affected_rows($con);
if($affected_row > 0)
{
	echo 'success';
	
}
else
{
	echo 'failure';
}
?>