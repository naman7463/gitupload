<?php 
require_once 'check_session.php';
require_once 'code/config.php';
require_once 'header.php' ; 

$post_id = $_POST['post_id'];
$post_title = $_POST['post_title'];
$post_address = $_POST['post_address'];


// update record

$sql_posts = "update `posts` set `post_title` = '$post_title' , `address` = '$post_address'  where `post_id` = '$post_id' ";
$query_posts = mysqli_query($con,$sql_posts);
$affected_row = mysqli_affected_rows($con);
if($affected_row > 0)
{
	echo 'success';
	
}
else
{
	echo 'failure';
}
?>